/**
 * Card Class contains methods that deals with a Card
 * I pledge my honor
 */

public class Card {
    public static final int A = 14;
    public static final int K = 13;
    public static final int Q = 12;
    public static final int J = 11;
    private int rank;
    private String suit;

    /**
     * Creates a Poker Card
     */
    public Card(int rank, String suit){
        this.rank = rank;
        this.suit = suit;
    }

    /**
     * Gets the rank of Poker Card
     * @return the cards rank
     */
    public int getRank(){
        return rank;
    }

    /**
     * Gets the suit of Poker Card
     * @return the cards suit
     */
    public String getSuit(){
        return suit;
    }

    /**
     * Represents the Card Object as a string
     * @return string format of a card
     */
    public String toString()
    {
        if(rank == A){
            // needs constants
            return "A" + " of " + suit;
        }
        if(rank == K){
            // needs constants
            return "K" + " of " + suit;
        }
        if(rank == Q){
            // needs constants
            return "Q" + " of " + suit;
        }
        if(rank == J){
            // needs constants
            return "J" + " of " + suit;
        }
        return rank + " of " + suit;
    }

    /**
     * Compares if two cards are the same
     * @return True if Decks are Equal, False otherwise
     */
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        } else if (other == null) {
            return false;
        } else if (!(other instanceof Card)) {
            return false;
        } else {
            Card otherCard = (Card) other; //casting other to be a card object
            return otherCard.getSuit().equals(this.getSuit()) &&
                    otherCard.getRank() == this.getRank();
        }
    }

    public static void main(String[]args){
        Card  C1 = new Card(13,"C");
        System.out.print("Card1: ");
        System.out.println(C1);
        System.out.print("Card1 Rank: ");
        System.out.println(C1.getRank());
        System.out.print("Card1 Suit: ");
        System.out.println(C1.getSuit());
        Card C2 = new Card(13,"C");
        System.out.print("Card2: ");
        System.out.println(C2);
        System.out.print("Is Card 1 the same as Card 2: ");
        System.out.println(C1.equals(C2));
        System.out.print("Is Card 1 the same as Card 1: ");
        System.out.println(C1.equals(C1));
        Deck D1 = new Deck();
        System.out.print("Is Card 1 the same as Deck1: ");
        System.out.println(C1.equals(D1));
        System.out.print("Is Card 1 the same as Null: ");
        System.out.println(C1.equals(12));
    }

}