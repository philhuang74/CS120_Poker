import java.util.ArrayList;

public class CommunityCardSet {

    private ArrayList<Card> communityCards;

    /**
     * Creates a Community Card Set Object
     */
    public CommunityCardSet(){

        this.communityCards = new ArrayList<Card>();
    }

    /**
     * Represents the Community Card Set object in String Format
     *
     * @return string format of the Community Card Set
     */
    public String toString() {

        String cards = this.communityCards.toString();
        cards = cards.substring(1, cards.length()-1);
        cards = cards.replace(',', ';');
        return cards;
    }

    /**
     * Returns the size of the communityCards list
     * @return size of this.communityCards
     */
    public int getSize() {
        return this.communityCards.size();
    }

    /**
     * Returns the cards in this Community Card Set
     * @return list of cards in this Community Card Set
     */
    public ArrayList<Card> getCards(){
        return this.communityCards;
    }

    /**
     * Returns the copy of the cards in this Community Card Set
     * @return copied list of cards in this Community Card Set
     */
    private ArrayList<Card> getCopy(){
        ArrayList<Card> copy = new ArrayList<Card>(communityCards);
//        copy.addAll(this.communityCards);
        return copy;
    }

    /**
     * Adds a specific card to the Community Card Set
     * @param card
     */
    public void addCard(Card card) {
        this.communityCards.add(card);
    }

    /**
     * Removes a specific card from the Community Card Set
     * @param card
     */
    public void removeCard(Card card) {
        this.communityCards.remove(card);
    }

    /**
     * Removes the card last dealt from the Community Card Set
     */
    public void removeCard() {
        this.communityCards.remove(communityCards.get(communityCards.size()-1));
    }
    /**
     * Compares if two CommunityCardSets are the same
     * @return True if CommunityCardSets are Equal, False otherwise
     */
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        } else if (other == null) {
            return false;
        } else if (!(other instanceof CommunityCardSet)) {
            return false;
        } else {
            CommunityCardSet otherHand = (CommunityCardSet) other; //casting other to be a CommunityCardSet object
            return otherHand.communityCards.containsAll(this.communityCards); //cards can be in different orders
        }
    }
    public static void main(String[] args) {
        Deck D1 = new Deck();
        CommunityCardSet C1 = new CommunityCardSet();
        C1.addCard(D1.dealaCard());
        C1.addCard(D1.dealaCard());
        System.out.print("Community Card Set after Two Deals: ");
        System.out.println(C1);
        C1.removeCard();
        System.out.print("Deck: ");
        System.out.println(D1);
        System.out.print("Community Card Set after removing the first card: ");
        System.out.println(C1);
        Deck D2 = new Deck();
        CommunityCardSet C2 = new CommunityCardSet();
        Card Card1 = D2.dealaCard();
        Card Card2 = D2.dealaCard();
        C2.addCard(Card1);
        C2.addCard(Card2);
        System.out.print("Community Card Set after Two Deals: ");
        System.out.println(C2);
        C2.removeCard(Card2);
        System.out.print("Community Card Set after removing the Card 2: ");
        System.out.println(C2);
        CommunityCardSet C3 = new CommunityCardSet();
        C3.addCard(new Card(5,"C"));
        C3.addCard(new Card(6,"C"));
        System.out.println("Community Card Set 3: "+ C3);
        CommunityCardSet C4 = new CommunityCardSet();
        C4.addCard(new Card(6,"C"));
        C4.addCard(new Card(5,"C"));
        System.out.println("Community Card Set 4: "+ C4);
        System.out.print("Is Community Card Set 3 equal to Community Card Set 4: ");
        System.out.println(C3.equals(C4));

    }
}
