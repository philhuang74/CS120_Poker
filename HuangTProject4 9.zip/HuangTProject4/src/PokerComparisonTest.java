/**
 * This Test class tests compareTo method and what ieType PokerHand methods in PokerHand class
 */
public class PokerComparisonTest {

    /**
     * Helps with testing High Card Hands
     */
    private static PokerHand addHigh(int rank1, int rank2, int rank3, int rank4, int rank5) {
        PokerHand TestHand = new PokerHand();
        TestHand.addCard(new Card(rank1, "C"));
        TestHand.addCard(new Card(rank2, "S"));
        TestHand.addCard(new Card(rank3, "D"));
        TestHand.addCard(new Card(rank4, "H"));
        TestHand.addCard(new Card(rank5, "C"));
        return TestHand;
    }

    /**
     *Helps with testing Pair Hands
     */
    private static PokerHand addPair(int rank1, int rank2, int rank3, int rank4) {
        PokerHand TestHand = new PokerHand();
        TestHand.addCard(new Card(rank1, "C"));
        TestHand.addCard(new Card(rank1, "D"));
        TestHand.addCard(new Card(rank2, "H"));
        TestHand.addCard(new Card(rank3, "S"));
        TestHand.addCard(new Card(rank4, "D"));
        return TestHand;
    }

    /**
     *Helps with testing Two Pair Hands
     */
    private static PokerHand addTwoPair(int rank1, int rank2, int rank3) {
        PokerHand TestHand = new PokerHand();
        TestHand.addCard(new Card(rank1, "C"));
        TestHand.addCard(new Card(rank1, "D"));
        TestHand.addCard(new Card(rank2, "C"));
        TestHand.addCard(new Card(rank2, "D"));
        TestHand.addCard(new Card(rank3, "C"));
        return TestHand;
    }

    /**
     *Helps with testing Flush Hands
     */
    private static PokerHand addFlush(int rank1, int rank2, int rank3, int rank4, int rank5, String suit) {
        PokerHand TestHand = new PokerHand();
        TestHand.addCard(new Card(rank1, suit));
        TestHand.addCard(new Card(rank2, suit));
        TestHand.addCard(new Card(rank3, suit));
        TestHand.addCard(new Card(rank4, suit));
        TestHand.addCard(new Card(rank5, suit));
        return TestHand;
    }

    /**
     *Test cases for isHigh method
     */
    private static void testisHigh(Tester t) {

        t.testSection("Test isHigh");
        // Not a High Card
        PokerHand NotHigh = addTwoPair(2,12,5);
        t.assertEquals("isHigh, false case", false, NotHigh.isHigh());

        // Is High Card
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("isHigh, true case", true, High.isHigh());
    }

    /**
     *Test cases for isPair method
     */
    private static void testisPair(Tester t) {

        t.testSection("Test isPair");
        // Two Pairs, 2 pair
        PokerHand TwoPair = addTwoPair(2,12,5);
        t.assertEquals("test isPair with a Two-Pair hand", false, TwoPair.isPair());

        // High Card
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("test isPair with a High Card", false, High.isPair());

        // Two Pair, 4 of a Kind
        PokerHand FourOfAKind = addTwoPair(2,2,14);
        t.assertEquals("test isPair with a Two Pair that is 4 of a Kind", false, FourOfAKind.isPair());

        // Two Pair, Full House
        PokerHand FullHouse = addTwoPair(8,2,2);
        t.assertEquals("test isPair with a Full House", false, FullHouse.isPair());

        // Pair, pair
        PokerHand Pair = addPair(2,12,13,14);
        t.assertEquals("test isPair with a Pair", true, Pair.isPair());

        // Pair, 3 pair
        PokerHand ThreePair = addPair(2,2,13,14);
        t.assertEquals("test isPair with a 3 Pair", true, ThreePair.isPair());

        // Flush
        PokerHand Flush = addFlush(11,3,6,4,13,"D");
        t.assertEquals("test isPair with a Flush", false, Flush.isPair());
    }

    /**
     *Test cases for isTwoPair
     */
    private static void testisTwoPair(Tester t) {

        t.testSection("Test isTwoPair");
        // Two Pairs, 2 pair
        PokerHand TwoPair = addTwoPair(2,12,5);
        t.assertEquals("test isTwoPair with a Two-Pair hand", true, TwoPair.isTwoPair());

        // High Card
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("test isTwoPair with a High Card", false, High.isTwoPair());

        // Two Pair, 4 of a Kind
        PokerHand FourOfAKind = addTwoPair(2,2,14);
        t.assertEquals("test isTwoPair with a Two Pair that is 4 of a Kind", true, FourOfAKind.isTwoPair());

        // Two Pair, Full House
        PokerHand FullHouse = addTwoPair(8,2,2);
        t.assertEquals("test isTwoPair with a Full House", true, FullHouse.isTwoPair());

        // Pair, pair
        PokerHand Pair = addPair(2,12,13,14);
        t.assertEquals("test isTwoPair with a Pair", false, Pair.isTwoPair());

        // Pair, 3 pair
        PokerHand ThreePair = addPair(2,2,13,14);
        t.assertEquals("test isTwoPair with a 3 Pair", false, ThreePair.isTwoPair());

        // Flush
        PokerHand Flush = addFlush(11,3,6,4,13,"D");
        t.assertEquals("test isTwoPair with a Flush", false, Flush.isTwoPair());
    }

    /**
     *Test cases for isFlush
     */
    private static void testisFlush(Tester t) {

        t.testSection("Test isFlush");
        // Not a Flush
        PokerHand NotFlush = addHigh(11,3,6,4,13);
        t.assertEquals("isFlush, false case", false, NotFlush.isFlush());

        // Is Flush
        PokerHand Flush = addFlush(11,3,6,4,13,"D");
        t.assertEquals("isFlush, true case", true, Flush.isFlush());
    }

    /**
     *Test cases that compare High Card hands
     */
    private static void testcompareHighs(Tester t) {

        t.testSection("Test compareTo High-Cards");
        // High-Card and High-Card, 0 case
        PokerHand High = addHigh(9,11,12,13,14);
        t.assertEquals("High-Card compareTo High-Card, 0 case", 0, High.compareTo(High));

        // High-Card and High-Card, -1 case
        PokerHand High2 = addHigh(10,11,12,13,14);
        t.assertEquals("High-Card compareTo High-Card, -1 case", -1, High.compareTo(High2));

        // High-Card and High-Card, 1 case
        t.assertEquals("High-Card and High-Card, 1 case", 1, High2.compareTo(High));

    }

    /**
     *Test cases that compare Pair hands
     */
    private static void testcomparePairs(Tester t) {

        t.testSection("Test compareTo Pairs");
        // Pair and High-Card
        PokerHand Pair = addPair(2,12,13,14);
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("Pair compareTo High-Card", 1, Pair.compareTo(High));

        // Pair and Two-Pair
        PokerHand TwoPair = addTwoPair(2,12,5);
        t.assertEquals("Pair compareTo Two-Pair", -1, Pair.compareTo(TwoPair));

        // Pair and Pair, -1 case
        PokerHand Pair3 = addPair(3,12,13,14);
        t.assertEquals("Pair compareTo Pair, -1 case", -1, Pair.compareTo(Pair3));

        // Pair and Pair, 0 case
        t.assertEquals("Pair compareTo Pair, 0 case", 0, Pair.compareTo(Pair));

        // Pair and Pair, 1 case
        t.assertEquals("Pair compareTo Pair, 1 case", 1, Pair3.compareTo(Pair));

        // Pair and Pair, 1 case (3 Pair)
        PokerHand ThreePair3 = addPair(3,3,13,14);
        PokerHand ThreePair2 = addPair(2,2,13,14);
        t.assertEquals("Pair compareTo Pair", 1, ThreePair3.compareTo(ThreePair2));

    }

    /**
     *Test cases that compare TwoPair hands
     */
    private static void testcompareTwoPairs(Tester t) {

        t.testSection("Test compareTo Two-Pairs");
        // Two-Pair and High-Card
        PokerHand TwoPair = addTwoPair(2,12,5);
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("Two-Pair compareTo High-Card", 1, TwoPair.compareTo(High));

        // Two-Pair and Two-Pair, -1 case
        PokerHand TwoPair3n12 = addTwoPair(3,12,5);
        t.assertEquals("Two-Pair compareTo Two-Pair, -1 case", -1, TwoPair.compareTo(TwoPair3n12));

        // Two-Pair and Two-Pair, -1 case (4 of a Kind)
        PokerHand FourOfAKind9 = addTwoPair(9,9,14);
        PokerHand FourOfAKind10 = addTwoPair(10,10,14);
        t.assertEquals("Two-Pair compareTo Two-Pair, -1 case (4 of a Kind)", -1, FourOfAKind9.compareTo(FourOfAKind10));

        // Two-Pair and Two-Pair, -1 case (full house)
        PokerHand FullHouse2n10 = addTwoPair(10,2,2);
        PokerHand FullHouse3n10 = addTwoPair(10,3,3);
        t.assertEquals("Two-Pair compareTo Two-Pair, -1 case (full house)", -1, FullHouse2n10.compareTo(FullHouse3n10));

        // Two-Pair and Two-Pair, 0 case
        t.assertEquals("Two-Pair compareTo Two-Pair, 0 case", 0, TwoPair.compareTo(TwoPair));

        // Two-Pair and Two-Pair, 1 case (different two-pairs)
        t.assertEquals("Two-Pair compareTo Two-Pair, 1 case (different two-pairs)", 1, TwoPair3n12.compareTo(TwoPair));

        // Two-Pair and Two-Pair, 1 case (same two-pairs, different high card)
        PokerHand TwoPair2n12n6 = addTwoPair(2,12,6);
        t.assertEquals("Two-Pair compareTo Two-Pair, 1 case (same two-pairs, different high card)", 1, TwoPair2n12n6.compareTo(TwoPair));

    }

    /**
     *Test cases that compare Flush hands
     */
    private static void testcompareFlushes(Tester t) {

        t.testSection("Test compareTo Flushes");
        // Flush and High-Card
        PokerHand Flush = addFlush(11,3,6,4,13,"D");
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("Flush compareTo High Card", 1, Flush.compareTo(High));

        // Flush and Pair
        PokerHand Pair = addPair(2,12,13,14);
        t.assertEquals("Flush compareTo Pair", 1, Flush.compareTo(Pair));

        // Flush and Two-Pair
        PokerHand TwoPair = addTwoPair(2,12,5);
        t.assertEquals("Flush compareTo Two-Pair", 1, Flush.compareTo(TwoPair));

        // Flush and Flush, 0 case
        PokerHand Flush2 = addFlush(11,3,6,4,13,"D");
        t.assertEquals("Flush compareTo Flush, 0 case", 0, Flush.compareTo(Flush2));

        // Flush and Flush, -1 case (8-High Flush and 9-High Flush)
        PokerHand SixHighFlush = addFlush(2,3,4,6,8,"S");
        PokerHand NineHighFlush = addFlush(2,3,4,5,9,"H");
        t.assertEquals("Flush compareTo Flush, -1 case (8-High Flush and 9-High Flush", -1, SixHighFlush.compareTo(NineHighFlush));

        // Flush and Flush, 1 case (King-Queen-High Flush and King-Jack-High-Flush)
        PokerHand KQHighFlush = addFlush(2,3,4,12,13,"H");
        PokerHand KJHighFlush = addFlush(2,3,4,11,13,"S")   ;
        t.assertEquals("Flush compareTo Flush, 1 case (King-Queen-High Flush and King-Jack-High-Flush)", 1, KQHighFlush.compareTo(KJHighFlush));

    }

    private static StudPokerHand getStudHigh() {
        CommunityCardSet C1 = new CommunityCardSet();
        C1.addCard(new Card(2,"S"));
        C1.addCard(new Card(5,"C"));
        C1.addCard(new Card(6,"D"));
        C1.addCard(new Card(13,"S"));
        C1.addCard(new Card(10,"H"));
        StudPokerHand S1 = new StudPokerHand(C1);
        S1.addCard(new Card(7, "D"));
        S1.addCard(new Card(12, "H"));
        return S1;
    }

    private static StudPokerHand getStudPair() {
        CommunityCardSet C1 = new CommunityCardSet();
        C1.addCard(new Card(2,"S"));
        C1.addCard(new Card(5,"C"));
        C1.addCard(new Card(6,"D"));
        C1.addCard(new Card(13,"S"));
        C1.addCard(new Card(10,"H"));
        StudPokerHand S1 = new StudPokerHand(C1);
        S1.addCard(new Card(2, "D"));
        S1.addCard(new Card(12, "H"));
        return S1;
    }

    private static StudPokerHand getStudTwoPair() {
        CommunityCardSet C1 = new CommunityCardSet();
        C1.addCard(new Card(2,"S"));
        C1.addCard(new Card(5,"C"));
        C1.addCard(new Card(6,"D"));
        C1.addCard(new Card(13,"S"));
        C1.addCard(new Card(10,"H"));
        StudPokerHand S1 = new StudPokerHand(C1);
        S1.addCard(new Card(2, "D"));
        S1.addCard(new Card(13, "H"));
        return S1;
    }

    private static StudPokerHand getStudFlush() {
        CommunityCardSet C1 = new CommunityCardSet();
        C1.addCard(new Card(2,"S"));
        C1.addCard(new Card(5,"S"));
        C1.addCard(new Card(6,"D"));
        C1.addCard(new Card(13,"S"));
        C1.addCard(new Card(10,"H"));
        StudPokerHand S1 = new StudPokerHand(C1);
        S1.addCard(new Card(7, "S"));
        S1.addCard(new Card(12, "S"));
        return S1;
    }

    private static CommunityCardSet getCommunity(Card c1, Card c2, Card c3, Card c4, Card c5) {
        CommunityCardSet C1 = new CommunityCardSet();
        C1.addCard(c1);
        C1.addCard(c2);
        C1.addCard(c3);
        C1.addCard(c4);
        C1.addCard(c5);
        return C1;
    }

    private static StudPokerHand getStud(CommunityCardSet C1, Card card1, Card card2) {
        StudPokerHand S1 = new StudPokerHand(C1);
        S1.addCard(card1);
        S1.addCard(card2);
        return S1;
    }

    /**
     * Test isHigh of the Best of Stud Poker Hand
     */
    private static void testBestisHigh(Tester t) {

        t.testSection("Test isHigh of the Best of Stud Poker Hand");
        // Not a High Card
        StudPokerHand NotHigh = getStudTwoPair();
        t.assertEquals("Best of Stud Poker Hand is not High", false, NotHigh.isHigh());

        // Is High Card
        StudPokerHand High = getStudHigh();
        t.assertEquals("Best of Stud Poker Hand is High", true, High.isHigh());
    }

    /**
     * Test isPair of the Best of Stud Poker Hand
     */
    private static void testBestisPair(Tester t) {

        t.testSection("Test isPair of the Best of Stud Poker Hand");
        // Not a Pair Hand
        StudPokerHand NotPair = getStudTwoPair();
        t.assertEquals("Best of Stud Poker Hand is not Pair", false, NotPair.isPair());

        // Is Pair Hand
        StudPokerHand Pair = getStudPair();
        t.assertEquals("Best of Stud Poker Hand is Pair", true, Pair.isPair());
    }

    /**
     * Test isTwoPair of the Best of Stud Poker Hand
     */
    private static void testBestisTwoPair(Tester t) {

        t.testSection("Test isTwoPair of the Best of Stud Poker Hand");
        // Not a Two-Pair Hand
        StudPokerHand NotTwoPair = getStudFlush();
        t.assertEquals("Best of Stud Poker Hand is not Two-Pair", false, NotTwoPair.isTwoPair());

        // Is Two-Pair Hand
        StudPokerHand TwoPair = getStudTwoPair();
        t.assertEquals("Best of Stud Poker Hand is Two-Pair", true, TwoPair.isTwoPair());
    }

    /**
     * Test isFlush of the Best of Stud Poker Hand
     */
    private static void testBestisFlush(Tester t) {

        t.testSection("Test isFlush of the Best of Stud Poker Hand");
        // Not a Flush Hand
        StudPokerHand NotFlush = getStudHigh();
        t.assertEquals("Best of Stud Poker Hand is not Flush", false, NotFlush.isFlush());

        // Is Flush Hand
        StudPokerHand Flush = getStudFlush();
        t.assertEquals("Best of Stud Poker Hand is Flush", true, Flush.isFlush());
    }

    /**
     *Test cases that compare High-Card Stud Poker Hands
     */
    private static void testcompareStudHighs(Tester t) {

        CommunityCardSet C1 = getCommunity(new Card(2, "S"), new Card(5, "C"), new Card(6, "D"), new Card(13, "S"), new Card(10, "H"));
        StudPokerHand S1 = getStud(C1, new Card(7, "D"), new Card(12, "H"));
        StudPokerHand S2 = getStud(C1, new Card(8, "D"), new Card(14, "H"));
        StudPokerHand S3 = getStud(C1, new Card(7, "H"), new Card(12, "S"));

        t.testSection("Test compareTo High-Card Stud Poker Hands");

        // High-Card and High-Card, 0 case
        t.assertEquals("High-Card compareTo High-Card, 0 case", 0, S1.compareTo(S3));

        // High-Card and High-Card, -1 case
        t.assertEquals("High-Card compareTo High-Card, -1 case", -1, S1.compareTo(S2));

        // High-Card and High-Card, 1 case
        t.assertEquals("High-Card and High-Card, 1 case", 1, S2.compareTo(S1));

        // High-Card and Flush
        StudPokerHand High = getStudHigh();
        StudPokerHand Flush = getStudFlush();
        t.assertEquals("High-Card compareTo Flush", -1, High.compareTo(Flush));

        // High-Card and Two-Pair
        StudPokerHand TwoPair = getStudTwoPair();
        t.assertEquals("High-Card compareTo Two-Pair", -1, High.compareTo(TwoPair));

        // High-Card and Pair
        StudPokerHand Pair = getStudPair();
        t.assertEquals("High-Card compareTo Pair", -1, High.compareTo(Pair));
    }

    /**
     *Test cases that compare Pair Stud Poker Hands
     */
    private static void testcompareStudPairs(Tester t) {

        CommunityCardSet C1 = getCommunity(new Card(2, "S"), new Card(5, "C"), new Card(6, "D"), new Card(13, "S"), new Card(10, "H"));
        StudPokerHand S1 = getStud(C1, new Card(2, "D"), new Card(12, "H"));
        StudPokerHand S2 = getStud(C1, new Card(5, "D"), new Card(14, "H"));
        StudPokerHand S3 = getStud(C1, new Card(2, "H"), new Card(12, "S"));

        t.testSection("Test compareTo Pair Stud Poker Hands");

        // Pair and Pair, 0 case
        t.assertEquals("Pair compareTo Pair, 0 case", 0, S1.compareTo(S3));

        // Pair and Pair, -1 case
        t.assertEquals("Pair compareTo Pair, -1 case", -1, S1.compareTo(S2));

        // Pair and Pair, 1 case
        t.assertEquals("Pair compareTo Pair, 1 case", 1, S2.compareTo(S1));

        // Pair and High
        StudPokerHand Pair = getStudPair();
        StudPokerHand High = getStudHigh();
        t.assertEquals("Pair compareTo High-Card", 1, Pair.compareTo(High));

        // Pair and Two-Pair
        StudPokerHand TwoPair = getStudTwoPair();
        t.assertEquals("Pair compareTo Two-Pair", -1, Pair.compareTo(TwoPair));

        // Pair and Flush
        StudPokerHand Flush = getStudFlush();
        t.assertEquals("Pair compareTo Flush", -1, Pair.compareTo(Flush));
    }

    /**
     *Test cases that compare Two-Pair Stud Poker Hands
     */
    private static void testcompareStudTwoPairs(Tester t) {

        CommunityCardSet C1 = getCommunity(new Card(2, "S"), new Card(5, "C"), new Card(6, "D"), new Card(13, "S"), new Card(10, "H"));
        StudPokerHand S1 = getStud(C1, new Card(2, "D"), new Card(5, "H"));
        StudPokerHand S2 = getStud(C1, new Card(13, "D"), new Card(6, "H"));
        StudPokerHand S3 = getStud(C1, new Card(2, "H"), new Card(5, "S"));

        t.testSection("Test compareTo Two-Pair Stud Poker Hands");

        // Two-Pair compareTo Two-Pair, 0 case
        t.assertEquals("Two-Pair compareTo Two-Pair, 0 case", 0, S1.compareTo(S3));

        // Two-Pair compareTo Two-Pair, -1 case
        t.assertEquals("Two-Pair compareTo Two-Pair, -1 case", -1, S1.compareTo(S2));

        // Two-Pair compareTo Two-Pair, 1 case
        t.assertEquals("Two-Pair compareTo Two-Pair, 1 case", 1, S2.compareTo(S1));

        // Two-Pair and High
        StudPokerHand TwoPair = getStudTwoPair();
        StudPokerHand High = getStudHigh();
        t.assertEquals("Two-Pair compareTo High-Card", 1, TwoPair.compareTo(High));

        // Two-Pair and Pair
        StudPokerHand Pair = getStudPair();
        t.assertEquals("Two-Pair compareTo Pair", 1, TwoPair.compareTo(Pair));

        // Two-Pair and Flush
        StudPokerHand Flush = getStudFlush();
        t.assertEquals("Two-Pair compareTo Flush", -1, TwoPair.compareTo(Flush));

        CommunityCardSet C2 = getCommunity(new Card(12, "C"), new Card(7, "D"), new Card(7, "H"), new Card(11, "H"), new Card(12, "H"));
        StudPokerHand S21 = getStud(C2, new Card(9, "H"), new Card(5, "D"));
        StudPokerHand S22 = getStud(C2, new Card(10, "S"), new Card(12, "D"));

        // Compare Queen-7 Full House with Queen-7 Two-Pair and a Jack High-Card
        t.assertEquals("Q-7 Full House compareTo Q-7 2-Pair with J High-Card", -1, S21.compareTo(S22));

    }
    /**
     *Test cases that compare Flush Stud Poker Hands
     */
    private static void testcompareStudFlushes(Tester t) {

        CommunityCardSet C1 = getCommunity(new Card(2, "S"), new Card(5, "C"), new Card(6, "S"), new Card(13, "S"), new Card(10, "H"));
        CommunityCardSet C2 = getCommunity(new Card(2, "H"), new Card(5, "C"), new Card(6, "H"), new Card(13, "H"), new Card(10, "D"));
        CommunityCardSet C3 = getCommunity(new Card(2, "H"), new Card(5, "H"), new Card(6, "H"), new Card(13, "H"), new Card(10, "H"));
        StudPokerHand S1 = getStud(C1, new Card(7, "S"), new Card(12, "S"));
        StudPokerHand S2 = getStud(C1, new Card(8, "S"), new Card(14, "S"));
        StudPokerHand S3 = getStud(C2, new Card(7, "H"), new Card(12, "H"));
        StudPokerHand S31 = getStud(C3, new Card(7, "S"), new Card(12, "S"));
        StudPokerHand S32 = getStud(C3, new Card(8, "S"), new Card(14, "S"));

        t.testSection("Test compareTo Flush Stud Poker Hands");

        // Flush compareTo Flush, 0 case
        t.assertEquals("Flush compareTo Flush, 0 case", 0, S1.compareTo(S3));
        t.assertEquals("Flush compareTo Flush, 0 case (Community Cards is a Flush)", 0, S31.compareTo(S32));

        // Flush compareTo Flush, -1 case
        t.assertEquals("Flush compareTo Flush, -1 case", -1, S1.compareTo(S2));

        // Flush compareTo Flush, 1 case
        t.assertEquals("Flush compareTo Flush, 1 case", 1, S2.compareTo(S1));

        // Flush and High
        StudPokerHand Flush = getStudFlush();
        StudPokerHand High = getStudHigh();
        t.assertEquals("Flush compareTo High-Card", 1, Flush.compareTo(High));

        // Flush and Pair
        StudPokerHand Pair = getStudPair();
        t.assertEquals("Flush compareTo Pair", 1, Flush.compareTo(Pair));

        // Flush and Two-Pair
        StudPokerHand TwoPair = getStudTwoPair();
        t.assertEquals("Flush compareTo Two-Pair", 1, Flush.compareTo(TwoPair));
    }

    public static void main (String [] args) {
        Tester t = new Tester(true);
        testisHigh(t);
        testisPair(t);
        testisTwoPair(t);
        testisFlush(t);
        testcompareHighs(t);
        testcomparePairs(t);
        testcompareTwoPairs(t);
        testcompareFlushes(t);
        testBestisHigh(t);
        testBestisPair(t);
        testBestisTwoPair(t);
        testBestisFlush(t);
        testcompareStudHighs(t);
        testcompareStudPairs(t);
        testcompareStudTwoPairs(t);
        testcompareStudFlushes(t);
        t.finishTests();
    }

}