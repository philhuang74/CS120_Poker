import java.util.Scanner;
/**
 * Class that plays a game of comparing two PokerHands with one deck
 */
public class StudGame {

    public static final int NO_DRAW = 3;
    public static final int INITIAL = -3;
    public static final int COMMUNITY_SIZE = 5;
    public static final int STUD_SIZE = 2;

    private static int getAnswer(Scanner sc) {
        System.out.println("Enter a or b (or SPACE to indicate they are of equal value) ");
        String answer = sc.nextLine();
        while(!("a".equals(answer)) && !(" ".equals(answer)) && !("b".equals(answer))) {
            System.out.println("Try again, please enter a, b, or SPACE ");
            answer  = sc.nextLine();
        }
        return getANumber(answer);

    }

    private static int getANumber(String str) {
        // Initialize the variable number. Set it to an integer that is not -1, 0, or 1
        int number = INITIAL;
        if (str.equals("a")) {
            number = 1;
        } else if (str.equals(" ")) {
            number = 0;
        } else if (str.equals("b")) {
            number = -1;
        }
        return number;
    }

    private static String getAString(int number) {
        String str = "";
        if (number == 1) {
            str = "a";
        } else if (number == 0) {
            str = "<space>";
        } else if (number == -1) {
            str = "b";
        }
        return str;
    }

    private static CommunityCardSet getCommunityCardSet(Deck deck) {
        CommunityCardSet C1 = new CommunityCardSet();
        for (int i = 0; i < COMMUNITY_SIZE; i++) {
            C1.addCard(deck.dealaCard());
        }
        return C1;
    }

    private static StudPokerHand getStudPokerHand(Deck deck, CommunityCardSet communityCards) {
        StudPokerHand S1 = new StudPokerHand(communityCards);
        for (int i = 0; i < STUD_SIZE; i++) {
            S1.addCard(deck.dealaCard());
        }
        return S1;
    }

    public static void main(String[] args) {
        int score = 0;
        boolean gameOver = false;
        Deck Deck1 = new Deck();
        Deck1.shuffle();
        Scanner scanner = new Scanner(System.in);  // Create a Scanner object
        CommunityCardSet communityCards = getCommunityCardSet(Deck1);
        System.out.println("Enter return to start StudGame: ");
        while (Deck1.getNumCardsinDeck()> NO_DRAW && !gameOver) {
            String answer = scanner.nextLine();  // Reads user input
            if (answer.equals("")) {
                System.out.println("The community cards are: ");
                System.out.println(communityCards);
                //PokerHand, StudPokerHand, and CommunityCardSet classes do not mention Deck
                StudPokerHand Hand1 = getStudPokerHand(Deck1, communityCards);
                StudPokerHand Hand2 = getStudPokerHand(Deck1, communityCards);
                System.out.println("Which of the following hands is worth more? ");
                System.out.println("Hand A: \n" + Hand1 + "\n or \nHand B: \n" + Hand2);
                int answer_2 = getAnswer(scanner);
                System.out.println("got input: " + getAString(answer_2));
                if (answer_2 == Hand1.compareTo(Hand2)) {
                    System.out.println("Correct. The answer is " + getAString(Hand1.compareTo(Hand2)));
                    score += 1;
                } else {
                    System.out.println("Incorrect. The answer is " + getAString(Hand1.compareTo(Hand2)));
                    gameOver = true;
                }
            }
        }
        System.out.println("Game Over");
        System.out.println("Total Score: " + score);
        scanner.close();

    }

}

