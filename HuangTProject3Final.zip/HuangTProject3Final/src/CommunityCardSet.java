import java.util.ArrayList;

public class CommunityCardSet {
    private ArrayList<Card> communityCards;

    /**
     * Constructor that Creates a Community Card Set Object
     */
    public CommunityCardSet(){
        this.communityCards = new ArrayList<Card>();
    }

    /**
     * Represents the Community Card Set object in String Format
     *
     * @return string format of the Community Card Set
     */
    public String toString() {
        return this.communityCards.toString();
    }

    /**
     * A method that adds a specific card to the Community Card Set
     * @param card
     */
    public void addCard(Card card) {
        this.communityCards.add(card);
    }

    /**
     * A method that removes a specific card from the Community Card Set
     * @param card
     */
    public void removeCard(Card card) {
        this.communityCards.remove(card);
    }

    /**
     * A method that removes the card last dealt from the Community Card Set
     */
    public void removeCard() {
        this.communityCards.remove(communityCards.get(communityCards.size()-1));
    }
    public static void main(String[] args) {
        Deck D1 = new Deck();
        CommunityCardSet C1 = new CommunityCardSet();
        C1.addCard(D1.dealaCard());
        C1.addCard(D1.dealaCard());
        System.out.print("Community Card Set after Two Deals: ");
        System.out.println(C1);
        C1.removeCard();
        System.out.print("Deck: ");
        System.out.println(D1);
        System.out.print("Community Card Set after removing the first card: ");
        System.out.println(C1);
        Deck D2 = new Deck();
        CommunityCardSet C2 = new CommunityCardSet();
        Card Card1 = D2.dealaCard();
        Card Card2 = D2.dealaCard();
        C2.addCard(Card1);
        C2.addCard(Card2);
        System.out.print("Community Card Set after Two Deals: ");
        System.out.println(C2);
        C2.removeCard(Card2);
        System.out.print("Community Card Set after removing the Card 2: ");
        System.out.println(C2);
    }
}
