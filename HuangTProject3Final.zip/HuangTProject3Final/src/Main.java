import java.util.Scanner;
/**
 * Class that plays a game of comparing two PokerHands with one deck
 */
public class Main {

    public static final int NO_DRAW = 2;

    private static int getANumber(Scanner sc) {
        System.out.println("Enter a number");
        while (! sc.hasNextInt()) {
            System.out.println("Try again, please enter a number.");
            sc.nextLine();
        }
        return sc.nextInt();
    }

    public static void main(String[] args) {
        int score = 0;
        int count = 0;
        Deck Deck1 = new Deck();
        Deck1.shuffle();
        Scanner scanner = new Scanner(System.in);  // Create a Scanner object
        while (Deck1.getNumCardsinDeck()> NO_DRAW && count == 0) {
            PokerHand Hand1 = new PokerHand();
            PokerHand Hand2 = new PokerHand();
            System.out.println("Enter return to proceed the draw of two hands: ");
            String answer = scanner.nextLine();  // Reads user input
            if (answer.equals("")) {
                Hand1.dealHand(Deck1.dealaCard(), Deck1.dealaCard(), Deck1.dealaCard(), Deck1.dealaCard(), Deck1.dealaCard());
                Hand2.dealHand(Deck1.dealaCard(), Deck1.dealaCard(), Deck1.dealaCard(), Deck1.dealaCard(), Deck1.dealaCard());
                System.out.println("Hand1:"+ Hand1);
                System.out.println("Hand2:"+ Hand2);
                String question = "Which hand is greater? (Enter 1 for Hand1, -1 for Hand2, and 0 if they are equivalent) ";
                System.out.println(question);
                int answer_2 = getANumber(scanner);
                if (answer_2 == Hand1.compare_to(Hand2)) {
                    System.out.println("Correct. The answer is " + Hand1.compare_to(Hand2));
                    score += 1;
                } else {
                    count += 1;
                    System.out.println("Incorrect. The answer is " + Hand1.compare_to(Hand2));
                }
            }
        }
        System.out.println("Game Over");
        System.out.println("Total Score: " + score);
        scanner.close();

    }

}

