import java.util.ArrayList;

public class StudPokerHand {
    private ArrayList<Card> studHand;
    private ArrayList<CommunityCardSet> communityCards;
    public StudPokerHand(CommunityCardSet cCards) {
        this.studHand = new ArrayList<Card>();
        this.communityCards = new ArrayList<CommunityCardSet>();
        communityCards.add(cCards);
        }

    /**
     * Represents the Stud Poker Hand object in String Format
     *
     * @return string format of the Stud Poker Hand
     */
    public String toString() {
        return this.studHand.toString();
    }

    /**
     * A method that adds a specific card to the Stud Poker Hand
     * @param card
     */
    public void addCard(Card card) {
        this.studHand.add(card);
    }

    public void dealStudHand(Card card1, Card card2) {
        this.addCard(card1);
        this.addCard(card2);
    }

    /**
     * A method that removes a specific card from the Stud Poker Hand
     * @param card
     */
    public void removeCard(Card card) {
        this.studHand.remove(card);
    }

    /**
     * A method that removes the card last dealt from the Stud Poker Hand
     */
    public void removeCard() {
        this.studHand.remove(studHand.get(studHand.size()-1));
    }

    /**
     * A getter method that returns the size of the stud hand
     *
     * @return the size of the stud hand
     */
    public int getSize() {

        return this.studHand.size();
    }

    private ArrayList<PokerHand> getAllFiveCardHands(){
        ArrayList<PokerHand> HandList = new ArrayList();
        for (Card card: studHand){
            for (Card comcard: communityCards){

            }

        }
    }

    private PokerHand getBestFiveCardHand() {
        ArrayList<PokerHand> hands = getAllFiveCardHands();
        PokerHand bestSoFar = hands.get(0);

        for (int i = 1; i < hands.size(); i++) {
            if (hands.get(i).compare_to(bestSoFar) > 0) {
                bestSoFar = hands.get(i);
            }
        }
        return bestSoFar;
    }

    public int compare_to(StudPokerHand other) {
        return this.getBestFiveCardHand().compare_to(other.getBestFiveCardHand());
    }

    public static void main(String[] args){
        Deck D1 = new Deck();
        CommunityCardSet C1 = new CommunityCardSet();
        for(int i=0; i<5; i++){
            C1.addCard(D1.dealaCard());
        }
        System.out.println(C1);
        StudPokerHand S1 = new StudPokerHand(C1);
        for(int i=0; i<2; i++){
            S1.addCard(D1.dealaCard());
        }
        System.out.println(S1);

    }
}
