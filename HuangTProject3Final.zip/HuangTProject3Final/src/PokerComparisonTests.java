/**
 * This Test class tests compare_to method and what ieType PokerHand methods in PokerHand class
 */
public class PokerComparisonTests {

    /**
     * Helps with testing High Card Hands
     */
    private static PokerHand addHigh(int rank1, int rank2, int rank3, int rank4, int rank5) {
        PokerHand TestHand = new PokerHand();
        TestHand.addCard(new Card(rank1, "C"));
        TestHand.addCard(new Card(rank2, "S"));
        TestHand.addCard(new Card(rank3, "D"));
        TestHand.addCard(new Card(rank4, "H"));
        TestHand.addCard(new Card(rank5, "C"));
        return TestHand;
    }

    /**
     *Helps with testing Pair Hands
     */
    private static PokerHand addPair(int rank1, int rank2, int rank3, int rank4) {
        PokerHand TestHand = new PokerHand();
        TestHand.addCard(new Card(rank1, "C"));
        TestHand.addCard(new Card(rank1, "D"));
        TestHand.addCard(new Card(rank2, "H"));
        TestHand.addCard(new Card(rank3, "S"));
        TestHand.addCard(new Card(rank4, "D"));
        return TestHand;
    }

    /**
     *Helps with testing Two Pair Hands
     */
    private static PokerHand addTwoPair(int rank1, int rank2, int rank3) {
        PokerHand TestHand = new PokerHand();
        TestHand.addCard(new Card(rank1, "C"));
        TestHand.addCard(new Card(rank1, "D"));
        TestHand.addCard(new Card(rank2, "C"));
        TestHand.addCard(new Card(rank2, "D"));
        TestHand.addCard(new Card(rank3, "C"));
        return TestHand;
    }

    /**
     *Helps with testing Flush Hands
     */
    private static PokerHand addFlush(int rank1, int rank2, int rank3, int rank4, int rank5, String suit) {
        PokerHand TestHand = new PokerHand();
        TestHand.addCard(new Card(rank1, suit));
        TestHand.addCard(new Card(rank2, suit));
        TestHand.addCard(new Card(rank3, suit));
        TestHand.addCard(new Card(rank4, suit));
        TestHand.addCard(new Card(rank5, suit));
        return TestHand;
    }

    /**
     *Test cases for isHigh method
     */
    private static void testisHigh(Tester t) {

        t.testSection("Test isHigh");
        // Not a High Card
        PokerHand NotHigh = addTwoPair(2,12,5);
        t.assertEquals("isHigh, false case", false, NotHigh.isHigh());

        // Is High Card
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("isHigh, true case", true, High.isHigh());
    }

    /**
     *Test cases for isPair method
     */
    private static void testisPair(Tester t) {

        t.testSection("Test isPair");
        // Two Pairs, 2 pair
        PokerHand TwoPair = addTwoPair(2,12,5);
        t.assertEquals("test isPair with a Two-Pair hand", false, TwoPair.isPair());

        // High Card
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("test isPair with a High Card", false, High.isPair());

        // Two Pair, 4 of a Kind
        PokerHand FourOfAKind = addTwoPair(2,2,14);
        t.assertEquals("test isPair with a Two Pair that is 4 of a Kind", false, FourOfAKind.isPair());

        // Two Pair, Full House
        PokerHand FullHouse = addTwoPair(8,2,2);
        t.assertEquals("test isPair with a Full House", false, FullHouse.isPair());

        // Pair, pair
        PokerHand Pair = addPair(2,12,13,14);
        t.assertEquals("test isPair with a Pair", true, Pair.isPair());

        // Pair, 3 pair
        PokerHand ThreePair = addPair(2,2,13,14);
        t.assertEquals("test isPair with a 3 Pair", true, ThreePair.isPair());

        // Flush
        PokerHand Flush = addFlush(11,3,6,4,13,"D");
        t.assertEquals("test isPair with a Flush", false, Flush.isPair());
    }

    /**
     *Test cases for isTwoPair
     */
    private static void testisTwoPair(Tester t) {

        t.testSection("Test isTwoPair");
        // Two Pairs, 2 pair
        PokerHand TwoPair = addTwoPair(2,12,5);
        t.assertEquals("test isTwoPair with a Two-Pair hand", true, TwoPair.isTwoPair());

        // High Card
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("test isTwoPair with a High Card", false, High.isTwoPair());

        // Two Pair, 4 of a Kind
        PokerHand FourOfAKind = addTwoPair(2,2,14);
        t.assertEquals("test isTwoPair with a Two Pair that is 4 of a Kind", true, FourOfAKind.isTwoPair());

        // Two Pair, Full House
        PokerHand FullHouse = addTwoPair(8,2,2);
        t.assertEquals("test isTwoPair with a Full House", true, FullHouse.isTwoPair());

        // Pair, pair
        PokerHand Pair = addPair(2,12,13,14);
        t.assertEquals("test isTwoPair with a Pair", false, Pair.isTwoPair());

        // Pair, 3 pair
        PokerHand ThreePair = addPair(2,2,13,14);
        t.assertEquals("test isTwoPair with a 3 Pair", false, ThreePair.isTwoPair());

        // Flush
        PokerHand Flush = addFlush(11,3,6,4,13,"D");
        t.assertEquals("test isTwoPair with a Flush", false, Flush.isTwoPair());
    }

    /**
     *Test cases for isFlush
     */
    private static void testisFlush(Tester t) {

        t.testSection("Test isFlush");
        // Not a Flush
        PokerHand NotFlush = addHigh(11,3,6,4,13);
        t.assertEquals("isFlush, false case", false, NotFlush.isFlush());

        // Is Flush
        PokerHand Flush = addFlush(11,3,6,4,13,"D");
        t.assertEquals("isFlush, true case", true, Flush.isFlush());
    }

    /**
     *Test cases that compare High Card hands
     */
    private static void testcompareHighs(Tester t) {

        t.testSection("Test compare_to High-Cards");
        // High-Card and High-Card, 0 case
        PokerHand High = addHigh(9,11,12,13,14);
        t.assertEquals("High-Card compare_to High-Card, 0 case", 0, High.compare_to(High));

        // High-Card and High-Card, -1 case
        PokerHand High2 = addHigh(10,11,12,13,14);
        t.assertEquals("High-Card compare_to High-Card, -1 case", -1, High.compare_to(High2));

        // High-Card and High-Card, 1 case
        t.assertEquals("High-Card and High-Card, 1 case", 1, High2.compare_to(High));

    }

    /**
     *Test cases that compare Pair hands
     */
    private static void testcomparePairs(Tester t) {

        t.testSection("Test compare_to Pairs");
        // Pair and High-Card
        PokerHand Pair = addPair(2,12,13,14);
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("Pair compare_to High-Card", 1, Pair.compare_to(High));

        // Pair and Two-Pair
        PokerHand TwoPair = addTwoPair(2,12,5);
        t.assertEquals("Pair compare_to Two-Pair", -1, Pair.compare_to(TwoPair));

        // Pair and Pair, -1 case
        PokerHand Pair3 = addPair(3,12,13,14);
        t.assertEquals("Pair compare_to Pair, -1 case", -1, Pair.compare_to(Pair3));

        // Pair and Pair, 0 case
        t.assertEquals("Pair compare_to Pair, 0 case", 0, Pair.compare_to(Pair));

        // Pair and Pair, 1 case
        t.assertEquals("Pair compare_to Pair, 1 case", 1, Pair3.compare_to(Pair));

        // Pair and Pair, 1 case (3 Pair)
        PokerHand ThreePair3 = addPair(3,3,13,14);
        PokerHand ThreePair2 = addPair(2,2,13,14);
        t.assertEquals("Pair compare_to Pair", 1, ThreePair3.compare_to(ThreePair2));

    }

    /**
     *Test cases that compare TwoPair hands
     */
    private static void testcompareTwoPairs(Tester t) {

        t.testSection("Test compare_to Two-Pairs");
        // Two-Pair and High-Card
        PokerHand TwoPair = addTwoPair(2,12,5);
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("Two-Pair compare_to High-Card", 1, TwoPair.compare_to(High));

        // Two-Pair and Two-Pair, -1 case
        PokerHand TwoPair3n12 = addTwoPair(3,12,5);
        t.assertEquals("Two-Pair compare_to Two-Pair, -1 case", -1, TwoPair.compare_to(TwoPair3n12));

        // Two-Pair and Two-Pair, -1 case (4 of a Kind)
        PokerHand FourOfAKind9 = addTwoPair(9,9,14);
        PokerHand FourOfAKind10 = addTwoPair(10,10,14);
        t.assertEquals("Two-Pair compare_to Two-Pair, -1 case (4 of a Kind)", -1, FourOfAKind9.compare_to(FourOfAKind10));

        // Two-Pair and Two-Pair, -1 case (full house)
        PokerHand FullHouse2n10 = addTwoPair(10,2,2);
        PokerHand FullHouse3n10 = addTwoPair(10,3,3);
        t.assertEquals("Two-Pair compare_to Two-Pair, -1 case (full house)", -1, FullHouse2n10.compare_to(FullHouse3n10));

        // Two-Pair and Two-Pair, 0 case
        t.assertEquals("Two-Pair compare_to Two-Pair, 0 case", 0, TwoPair.compare_to(TwoPair));

        // Two-Pair and Two-Pair, 1 case (different two-pairs)
        t.assertEquals("Two-Pair compare_to Two-Pair, 1 case (different two-pairs)", 1, TwoPair3n12.compare_to(TwoPair));

        // Two-Pair and Two-Pair, 1 case (same two-pairs, different high card)
        PokerHand TwoPair2n12n6 = addTwoPair(2,12,6);
        t.assertEquals("Two-Pair compare_to Two-Pair, 1 case (same two-pairs, different high card)", 1, TwoPair2n12n6.compare_to(TwoPair));

    }

    /**
     *Test cases that compare Flush hands
     */
    private static void testcompareFlushes(Tester t) {

        t.testSection("Test compare_to Flushes");
        // Flush and High-Card
        PokerHand Flush = addFlush(11,3,6,4,13,"D");
        PokerHand High = addHigh(11,3,6,4,13);
        t.assertEquals("Flush compare_to High Card", 1, Flush.compare_to(High));

        // Flush and Pair
        PokerHand Pair = addPair(2,12,13,14);
        t.assertEquals("Flush compare_to Pair", 1, Flush.compare_to(Pair));

        // Flush and Two-Pair
        PokerHand TwoPair = addTwoPair(2,12,5);
        t.assertEquals("Flush compare_to Two-Pair", 1, Flush.compare_to(TwoPair));

        // Flush and Flush, 0 case
        PokerHand Flush2 = addFlush(11,3,6,4,13,"D");
        t.assertEquals("Flush compare_to Flush, 0 case", 0, Flush.compare_to(Flush2));

        // Flush and Flush, -1 case (8-High Flush and 9-High Flush)
        PokerHand SixHighFlush = addFlush(2,3,4,6,8,"S");
        PokerHand NineHighFlush = addFlush(2,3,4,5,9,"H");
        t.assertEquals("Flush compare_to Flush, -1 case (8-High Flush and 9-High Flush", -1, SixHighFlush.compare_to(NineHighFlush));

        // Flush and Flush, 1 case (King-Queen-High Flush and King-Jack-High-Flush)
        PokerHand KQHighFlush = addFlush(2,3,4,12,13,"H");
        PokerHand KJHighFlush = addFlush(2,3,4,11,13,"S")   ;
        t.assertEquals("Flush compare_to Flush, 1 case (King-Queen-High Flush and King-Jack-High-Flush)", 1, KQHighFlush.compare_to(KJHighFlush));

    }

    public static void main (String [] args) {
        Tester t = new Tester(true);
        testisHigh(t);
        testisPair(t);
        testisTwoPair(t);
        testisFlush(t);
        testcompareHighs(t);
        testcomparePairs(t);
        testcompareTwoPairs(t);
        testcompareFlushes(t);
        t.finishTests();
    }

}
