import java.util.ArrayList;
/**
 * PokerHand Class contains methods to deal with PokerHand
 */
public class PokerHand {

    // Constants
    public static int HAND_SIZE = 5;
    public static int ONE_PAIR = 2;
    public static int TWO_PAIR = 4;
    public static int THREE_PAIR = 3;
    public static int FOUR_OF_A_KIND = 4;
    public static int FULL_HOUSE = 5;
    public static int FLUSH_NUM = 5;
    public static int IS_HIGH_RANK = 1;
    public static int IS_PAIR_RANK = 2;
    public static int IS_TWO_PAIR_RANK = 3;
    public static int IS_FLUSH_RANK = 4;
    private ArrayList<Card> hand;

    /**
     * Constructor that Creates a Poker Hand Object
     *
     */
    public PokerHand() {

        this.hand = new ArrayList<Card>(); //default constructor

    }
    public PokerHand(ArrayList<Card> cards) {
        //this.hand = cards, is not a copy, just refers
        //this.hand = (ArrayList<Card>)cards.clone(); don't do this, needs casting
        this.hand = new ArrayList<Card>(cards);//copy constructor
    }

    /**
     * Represents the Poker Hand object in String Format
     *
     * @return string format of the Poker Hand
     */
    public String toString() {
        return this.hand.toString();
    }


    /**
     * A method that adds a specific card to the Poker Hand
     * @param card
     */
    public void addCard(Card card) {
        this.hand.add(card);

    }

    /**
     * A method that deals five specific cards to the Poker Hand
     * @param card1
     * @param card2
     * @param card3
     * @param card4
     * @param card5
     */
    public void dealHand(Card card1, Card card2, Card card3, Card card4, Card card5) {
        this.addCard(card1);
        this.addCard(card2);
        this.addCard(card3);
        this.addCard(card4);
        this.addCard(card5);
    }


    /**
     * A method to get the copy of a poker hand
     *
     * @return The copy of the poker hand
     */
    private ArrayList<Card> getCopy() {

        ArrayList<Card> copy = this.hand;
        return copy;
    }

    /**
     * A getter method that returns the size of the hand
     *
     * @return the size of the poker hand
     */
    public int getSize() {

        return this.hand.size();
    }

    /**
     * A method that gets the ranks in the poker hand
     *
     * @return the list of ranks of the cards
     */
    private ArrayList<Integer> getRanks() {

        ArrayList<Integer> ranks = new ArrayList<Integer>();
        for (Card card : this.hand) {
            int rank = card.getRank();
            ranks.add(rank);
        }
        return ranks;
    }

    /**
     * A method that gets the suits in the poker hand
     *
     * @return the list of suits of the cards
     */
    private ArrayList<String> getSuits() {

        ArrayList<String> suits = new ArrayList<String>();
        for (Card card : this.hand) {
            String suit = card.getSuit();
            suits.add(suit);
        }
        return suits;
    }

    /**
     * A method that counts the number of a certain rank in a list of ranks
     *
     * @param rank
     * @param ranks
     * @return number of a certain rank in a list of ranks
     */
    private int countRanks(int rank, ArrayList<Integer> ranks) {
        int count = 0;
        for (int i = 0; i < ranks.size(); i++) {
            if (ranks.get(i) == rank) {
                count++;
            }
        }
        return count;
    }

    /**
     * A method that counts the number of a certain suit in a list of suits
     *
     * @param the  suit that is going to be counted
     * @param list of suits
     * @return number of suit in the list of suits
     */
    private int countSuits(String suit, ArrayList<String> suits) {
        int count = 0;
        for (int i = 0; i < suits.size(); i++) {
            if (suits.get(i).equals(suit)) {
                count++;
            }
        }
        return count;
    }

    /**
     * A method that Determines whether the Poker Hand is a Pair
     *
     * @return True if the hand is Pair. False if otherwise.
     */
    public boolean isPair() {

        ArrayList<Integer> ranks = this.getRanks();
        int count = 0;
        for (int num : ranks) {
            int countRanks = this.countRanks(num, ranks);
            if (countRanks == ONE_PAIR || countRanks == THREE_PAIR) {
                count++;
            }
        }
        return count == ONE_PAIR || count == THREE_PAIR;
    }

    /**
     * A method that Determines whether the Poker Hand is a Two-Pair
     *
     * @return True if the hand is Two-Pair. False if otherwise.
     */
    public boolean isTwoPair() {

        ArrayList<Integer> ranks = this.getRanks();
        int count = 0;
        for (int num : ranks) {
            int countRanks = this.countRanks(num, ranks);
            if (countRanks == ONE_PAIR || countRanks == THREE_PAIR || countRanks == FOUR_OF_A_KIND) {
                count++;
            }
        }
        return count == TWO_PAIR || count == FULL_HOUSE;
    }

    /**
     * A method that Determines whether the Poker Hand is a Flush
     *
     * @return True if the hand is Flush. False if otherwise.
     */
    public boolean isFlush() {

        ArrayList<String> suits = this.getSuits();
        return this.countSuits(suits.get(0), suits) == FLUSH_NUM;
    }

    /**
     * A method that Determines whether the Poker Hand is a High Card
     *
     * @return True if the hand is High Card. False if otherwise.
     */
    public boolean isHigh() {

        return (!this.isPair()) && (!this.isTwoPair()) && (!this.isFlush());
    }

    /**
     * A getter method that returns the ranks of the pair in a hand
     *
     * @return list that contains the ranks of the pair
     */

    private ArrayList<Integer> getPairRanks(){
        ArrayList<Integer> pairRanks = new ArrayList<Integer>();
        if (this.isPair()) {
            ArrayList<Integer> ranks = this.getRanks();
            for (int num: ranks) {
                int countRanks = this.countRanks(num, ranks);
                if (countRanks == ONE_PAIR || countRanks == THREE_PAIR) {
                    pairRanks.add(num);
                }
            }
            return pairRanks;
        }
        return pairRanks;
    }
    /**
     * A getter method that returns the ranks of the two pairs in a hand
     *
     * @return list that contains the ranks of the two pairs
     */
    private ArrayList<Integer> getTwoPairRanks() {
        ArrayList<Integer> TwoPairRanks = new ArrayList<Integer>();
        if (this.isTwoPair()) {
            ArrayList<Integer> ranks = this.getRanks();
            for (int num : ranks) {
                int countRanks = this.countRanks(num, ranks);
                if (countRanks == ONE_PAIR || countRanks == THREE_PAIR || countRanks == FOUR_OF_A_KIND) {
                    TwoPairRanks.add(num);
                }
            }
            return TwoPairRanks;
        }
        return TwoPairRanks;
    }

    /**
     * A method that returns the maximum rank in a list of ranks
     *
     * @param ranks
     * @return maximum rank
     */
    private int maxRank(ArrayList<Integer> ranks) {
        int max = 0;
        for (int i = 0; i < ranks.size(); i++) {
            if (ranks.get(i) > max) {
                max = ranks.get(i);
            }
        }
        return max;
    }

    /**
     * A getter method that returns the highest pair in a Pair hand or a 2-Pair hand
     *
     * @return list of cards that are the highest pair in the hand
     */
    private ArrayList<Card> getHighestPair() {

        ArrayList<Card> highestPair = new ArrayList<Card>();
        ArrayList<Integer> pairRanks = new ArrayList<Integer>();

        if (this.isPair()) {
            pairRanks = this.getPairRanks();
        } else if (this.isTwoPair()) {
            pairRanks = this.getTwoPairRanks();
        }
        for (Card card : this.hand) {
            if (card.getRank() == this.maxRank(pairRanks)) {
                highestPair.add(card);
            }
        }
        return highestPair;
    }

    /**
     * A method that removes the pair in a Pair hand or the highest pair of a 2-Pair hand
     *
     * @return pair in a Pair hand or highest pair of a 2-Pair hand
     */
    private ArrayList<Card> removeHighestPair() {

        ArrayList<Card> highestPair = this.getHighestPair();
        for (Card card : highestPair) {
            this.hand.remove(card);
        }
        return highestPair;
    }

    /**
     * A getter method that returns a card with the
     * highest rank in a Flush or a High-Card
     *
     * @return a card with the highest rank in a Flush or a High-Card
     */
    private Card getHighestCard() {

        ArrayList<Integer> ranks = this.getRanks();
        for (Card card : this.hand) {
            if (card.getRank() == this.maxRank(ranks)) {
                return card;
            }
        }
        return null;
    }
    /**
     * A method that removes the highest card
     */
    private Card removeHighestCard() {

        Card highestCard = this.getHighestCard();
        this.hand.remove(highestCard);
        return highestCard;
    }

    /**
     * Determines how this Pair hand compares to another Pair hand, returns
     * positive, negative, or zero depending on the comparison.
     *
     * @param other: The other Pair hand to compare
     * @return -1 if self is worth LESS than other, 0
     * if they are worth the SAME, and 1 if self is worth
     * MORE than other
     */
    private int comparePairs(PokerHand other) {
        ArrayList<Integer> selfPairRanks = this.getPairRanks();
        ArrayList<Integer> otherPairRanks = other.getPairRanks();
        if (this.maxRank(selfPairRanks) > other.maxRank(otherPairRanks)) {
            return 1;
        } else if (this.maxRank(selfPairRanks) < other.maxRank(otherPairRanks)) {
            return -1;
        } else {
            this.removeHighestPair();
            other.removeHighestPair();
            return this.compareHighs(other);
        }
    }

    /**
     * Determines how this 2-Pair hand compares to another 2-Pair hand, returns
     * positive, negative, or zero depending on the comparison.
     *
     * @param other: The other 2-Pair hand to compare
     * @return -1 if self is worth LESS than other, 0
     * if they are worth the SAME, and 1 if self is worth
     * MORE than other
     */
    private int compareTwoPairs(PokerHand other) {
        ArrayList<Integer> selfTwoPairRanks = this.getTwoPairRanks();
        ArrayList<Integer> otherTwoPairRanks = other.getTwoPairRanks();
        if (this.maxRank(selfTwoPairRanks) > other.maxRank(otherTwoPairRanks)) {
            return 1;
        } else if (this.maxRank(selfTwoPairRanks) < other.maxRank(otherTwoPairRanks)) {
            return -1;
        } else {
            this.removeHighestPair();
            other.removeHighestPair();
            return this.comparePairs(other);
        }
    }

    /**
     * Determines how a High-Card hand compares to another High-Card hand,
     * and keeps comparing until there is a winner,
     * or it figures out the hands are the same.
     *
     * @param other: The other High-Card hand to compare
     * @return -1 if self is worth LESS than other, 0
     * if they are worth the SAME, and 1 if self is worth
     * MORE than other
     */
    private int compareHighs(PokerHand other) {

        ArrayList<Integer> selfRanks = this.getRanks();
        ArrayList<Integer> otherRanks = other.getRanks();
        if (this.maxRank(selfRanks) > other.maxRank(otherRanks)) {
            return 1;
        } else if (this.maxRank(selfRanks) < other.maxRank(otherRanks)) {
            return -1;
        } else {
            if (this.getSize() == 1 && other.getSize() == 1) {
                return 0;
            }
            this.removeHighestCard();
            other.removeHighestCard();
            return this.compareHighs(other);
        }
    }

    /**
     * A method that gives a value to the hand depending on its type.
     * The greater the value given to the hand, the higher the worth
     * of the hand. Order was determined from Project 1.
     *
     * @return 1 if hand is a High, 2 if hand is a Pair, 3 if hand is a Two-Pair,
     * 4 if hand is a Flush
     */
    private int handValue() {

        if (this.isHigh()) {

            return IS_HIGH_RANK;
        } else if (this.isPair()) {

            return IS_PAIR_RANK;
        } else if (this.isTwoPair()) {

            return IS_TWO_PAIR_RANK;
        }
        return IS_FLUSH_RANK;
    }

    /**
     * Determines how this hand compares to another hand, returns positive,
     * negative, or zero depending on the comparison.
     *
     * @param other: the second hand to compare
     * @return -1 if this hand is worth LESS than other, 0 if they are worth the SAME,
     * and a 1 if this hand is worth MORE than other
     */
    public int compare_to(PokerHand other) {

        ArrayList<Card> copy_self = this.getCopy();
        ArrayList<Card> copy_other = other.getCopy();
        if (this.handValue() > other.handValue()) {
            return 1;
        } else if (this.handValue() < other.handValue()) {
            return -1;
        } else {
            int result;
            if (this.isPair() && other.isPair()) {
                result = this.comparePairs(other);
            } else if (this.isTwoPair() && other.isTwoPair()) {
                result = this.compareTwoPairs(other);
            } else if (this.isFlush() && other.isFlush()) {
                result = this.compareHighs(other);
            } else {
                result = this.compareHighs(other);
            }
            this.hand = copy_self;
            other.hand = copy_other;
            return result;
        }
    }
    /**
     * A method that compares if two PokerHands are the same
     * @return True if PokerHands are Equal, False otherwise
     */
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        } else if (other == null) {
            return false;
        } else if (!(other instanceof PokerHand)) {
            return false;
        } else {
            PokerHand otherHand = (PokerHand) other; //casting other to be a PokerHand object
            return otherHand.hand.equals(this.hand);
        }
    }

    public static void main(String[] args) {

        System.out.println("Test for dealing hands from deck");
        Deck Deck1 = new Deck();
        Deck Deck2 = new Deck();
        Deck1.shuffle();
        Deck2.shuffle();
        PokerHand Hand1 = new PokerHand();
        PokerHand Hand2 = new PokerHand();
        Hand1.addCard(Deck1.dealaCard());
        Hand2.addCard(Deck2.dealaCard());
        System.out.println("Hand1: " + Hand1);
        System.out.println("Size of Hand1: " + Hand1.getSize());
        System.out.println("Hand2: " + Hand2);
        System.out.println("Size of Hand2: " + Hand2.getSize());
        ArrayList<PokerHand> HandList = new ArrayList<PokerHand>();
        HandList.add(Hand1);
        HandList.add(Hand2);
        System.out.println("List of Hand1 and Hand2: " + HandList);
        System.out.println("Remaining cards in Deck1: " + Deck1);
        System.out.println("The number of remaining cards in Deck1: " + Deck1.getNumCardsinDeck());
        System.out.println("Remaining cards in Deck2: " + Deck2);
        System.out.println("The number of remaining cards in Deck2: " + Deck2.getNumCardsinDeck());
        System.out.println("----------------------------");
        PokerHand Hand3 = new PokerHand();
        Hand3.dealHand(new Card(3, "C"), new Card(1, "D"), new Card(13, "C"), new Card(1, "C"), new Card(3, "D"));
        System.out.println("Hand3: " + Hand3);
        PokerHand Hand4 = new PokerHand();
        System.out.println("Hand4 before dealing: " + Hand4);
        Hand4.dealHand(new Card(5, "S"), new Card(5, "D"), new Card(5, "H"), new Card(2, "C"), new Card(2, "H"));
        System.out.println("Hand4 after dealing: " + Hand4);
        System.out.println("Comparing Hand 3 to Hand 4: " + Hand3.compare_to(Hand4));
        System.out.println("Is Hand4 still TwoPair: " + Hand4.isTwoPair());
        System.out.println("Hand4: " + Hand4);
        System.out.println("Is Hand3 still TwoPair: " + Hand3.isTwoPair());
        System.out.println("Hand3: " + Hand3);
        System.out.println("----------------------------");
        PokerHand Hand5 = new PokerHand();
        System.out.print("Hand 5: ");
        Hand5.addCard(new Card(5,"S"));
        Hand5.addCard(new Card(6,"S"));
        Hand5.addCard(new Card(6,"D"));
        Hand5.addCard(new Card(5,"H"));
        Hand5.addCard(new Card(5,"D"));
        System.out.println(Hand5);
        System.out.print("Is Hand 5 a pair: ");
        System.out.println(Hand5.isPair());
        System.out.print("Is Hand 5 a two pair: ");
        System.out.println(Hand5.isTwoPair());

        PokerHand Hand6 = new PokerHand();
        Hand6.addCard(new Card(5,"S"));
        Hand6.addCard(new Card(6,"S"));
        Hand6.addCard(new Card(6,"D"));
        Hand6.addCard(new Card(5,"H"));
        Hand6.addCard(new Card(5,"D"));
        System.out.print("Hand 6: ");
        System.out.println(Hand6);
        System.out.print("Is Hand 5 equal to Hand 6: ");
        System.out.println(Hand5.equals(Hand6));

    }
}
