import java.util.ArrayList;
import java.util.Collections;

/**
 * Deck Class contains methods that deals with a Deck
 */
public class Deck {

    private static String[] suits = new String[] {"C", "D", "H", "S"};
    public static final int SMALLEST_RANK = 2;
    public static final int NUM_RANKS = 14;
    private ArrayList<Card> deck;
    private int NumCards = 52;

    /**
     * Constructor that Creates a Brand New Sealed Deck of Cards Object
     */
    public Deck(){
        this.deck = new ArrayList<Card>();
        for (int rank = SMALLEST_RANK; rank <= NUM_RANKS; rank++){
            for (String suit: suits){
                deck.add(new Card(rank, suit));
            }
        }
    }

    /**
     * Represents the Deck Object as a string
     * @return string format of a deck
     */
    public String toString(){
        return this.getCardsinDeck().toString(); //ArrayList have their own toString methods
    }

    /**
     * A method that deals the first top card of the deck
     * @return first top card of the deck
     */
    public Card dealaCard() {
        int index = this.deck.size()-NumCards;
        Card card = this.deck.get(index);
        NumCards--;
        return card;
    }

    /**
     * A method that returns the number of cards
     * that are not dealt yet in the deck
     * @return number of cards in deck
     */
    public int getNumCardsinDeck() {

        return NumCards;

    }

    /**
     * A method that returns the number of cards
     * that are already dealt from the deck
     * @return the size of the OutofDeck list
     */
    public int getNumOutOfDeck() {

        return this.deck.size()-NumCards;
    }

    /**
     * A method that returns the Cards that are
     * not dealt yet from the deck
     * @return list of Cards that are not dealt yet from the deck
     */
    public ArrayList<Card> getCardsinDeck(){
        ArrayList<Card> CardsinDeck = new ArrayList<Card>();
        for (int i=this.deck.size()-NumCards; i<this.deck.size();i++) {
            CardsinDeck.add(this.deck.get(i));
        }
        return CardsinDeck;
    }

    /**
     * A method that returns the Cards that are
     * already dealt from the deck
     * @return list of Cards that are already dealt from the deck
     */
    public ArrayList<Card> getCardsOutOfDeck(){
        ArrayList<Card> CardsOutOfDeck = new ArrayList<Card>();
        for (int i=0; i<this.deck.size()-NumCards;i++) {
            CardsOutOfDeck.add(this.deck.get(i));
        }
        return CardsOutOfDeck;
    }
    /**
     * A method that Shuffles a Deck of Cards
     */
    public void shuffle(){

        Collections.shuffle(this.deck);
    }

    /**
     * A method that compares if two decks are the same
     * @return True if Decks are Equal, False otherwise
     */
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        } else if (other == null) {
            return false;
        } else if (!(other instanceof Deck)) {
            return false;
        } else {
            Deck otherDeck = (Deck) other; //casting other to be a deck object
            return otherDeck.getCardsinDeck().equals(this.getCardsinDeck());
        }
    }
    public static void main(String[] args) {
        Deck D1 = new Deck();
        System.out.print("Original Deck: ");
        System.out.println(D1);
        D1.shuffle();
        System.out.print("Shuffled Deck: ");
        System.out.println(D1);
        System.out.print("Card Dealt: ");
        Card cardDealt = D1.dealaCard();
        System.out.println(cardDealt);
        System.out.print("Deck after a dealt card: ");
        System.out.println(D1);
        System.out.print("Number of cards left in the deck: ");
        System.out.println(D1.getNumCardsinDeck());
        System.out.print("Number of cards dealt from the deck: ");
        System.out.println(D1.getNumOutOfDeck());
        System.out.print("Is the card dealt still in the deck?: ");
        System.out.println(D1.getCardsinDeck().contains(cardDealt));
        System.out.print("Cards dealt from the deck: ");
        System.out.println(D1.getCardsOutOfDeck());
        Deck D4 = new Deck();
        D4.shuffle();
        System.out.print("Deck 4: ");
        System.out.println(D4);
        Deck D5 = new Deck();
        System.out.print("Deck 5: ");
        System.out.println(D5);
        System.out.print("Is Deck 4 equal to Deck 5: ");
        System.out.println(D4.equals(D5));
        Deck D6 = new Deck();
        System.out.print("Deck 6: ");
        System.out.println(D6);
        System.out.print("Is Deck 6 equal to Deck 5: ");
        System.out.println(D6.equals(D5));

    }
}
