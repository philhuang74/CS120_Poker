import java.util.ArrayList;

public class StudPokerHand {
    public static int HOLE_CARD_SIZE = 2;
    public static int COM_CARD_SIZE = 5;
    public static int HAND_SIZE = 5;
    private ArrayList<Card> holeCards;
    private CommunityCardSet communityCards;

    /**
     * Creates a StudPokerHand Object
     * @param cCards CommunityCardSet object
     */
    public StudPokerHand(CommunityCardSet cCards) {

        this.holeCards = new ArrayList<Card>();
        this.communityCards = cCards;

    }

    /**
     * Represents the Stud Poker Hand object in String Format
     *
     * @return string format of the Stud Poker Hand
     */
    public String toString() {
        String cards = this.holeCards.toString();
        cards = cards.substring(1, cards.length()-1);
        cards = cards.replace(',', ';');
        return cards;
    }

    /**
     * Returns the community cards in this Stud Poker Hand
     * @return list of community cards in this Stud Poker Hand
     */
    private ArrayList<Card> getCommunityCards() {

        return this.communityCards.getCards();
    }

    /**
     * Adds a specific card to the Stud Poker Hand
     * @param card
     */
    public void addCard(Card card) {
        this.holeCards.add(card);
    }

    /**
     * Adds a specific Hand to the Stud Poker Hand
     * @param card1 Card
     * @param card2 Card
     */
    public void dealStudHand(Card card1, Card card2) {
        this.addCard(card1);
        this.addCard(card2);
    }
    /**
     * Adds a specific Hand to the Stud Poker Hand
     * @param cards a card list
     */
    public void dealStudHand(ArrayList<Card> cards){
        for(Card card: cards){
            this.addCard(card);
        }
    }

    /**
     * Removes a specific card from the Stud Poker Hand
     * @param card
     */
    public void removeCard(Card card) {
        this.holeCards.remove(card);
    }

    /**
     * Removes the card last dealt from the Stud Poker Hand
     */
    public void removeCard() {
        this.holeCards.remove(holeCards.size()-1);
    }

    /**
     * Returns the size of the stud hand
     *
     * @return the size of the stud hand
     */
    public int getSize() {

        return this.holeCards.size();
    }

    /**
     * Combines hole cards and community cards
     * @return The list of seven cards in hole cards and community cards
     */
    private ArrayList<Card> combineCommunityCards(){
        ArrayList<Card> sevenCardList = new ArrayList<Card>();
        sevenCardList.addAll(getCommunityCards());
        sevenCardList.addAll(this.holeCards);
        return sevenCardList;
    }

    /**
     * Changes the list of cards in a list into a list of PokerHands
     * @param listOfCardList list of cards list
     * @return The list of PokerHands
     */
    private ArrayList<PokerHand> changeToPokerHand(ArrayList<ArrayList<Card>> listOfCardList){
        ArrayList<PokerHand> handList = new ArrayList<PokerHand>();
        for (ArrayList<Card> cardList: listOfCardList) {
            handList.add(new PokerHand(cardList));
        }
        return handList;
    }
    /**
     * Returns all combinations of a 5-card hand from the list of hole cards and community cards combined
     * @return list of all possible 5-card PokerHands combinations
     */
    private ArrayList<PokerHand> getAllFiveCardHands(){
        ArrayList<Card> sevenCardList = combineCommunityCards();
        ArrayList<ArrayList<Card>> chooseFive = choose(sevenCardList,HAND_SIZE);
        return changeToPokerHand(chooseFive);
    }
    /**
     * Gets the best PokerHand from a list of all possible five-card PokerHands
     * @return the best PokerHand in the list
     */
    private PokerHand getBestFiveCardHand()
    {
        ArrayList<PokerHand> hands = getAllFiveCardHands();
        PokerHand bestSoFar = hands.get(0);

        for (int i = 1; i < hands.size(); i++) {
            if (hands.get(i).compareTo(bestSoFar) > 0) {
                bestSoFar = hands.get(i);
            }
        }
        return bestSoFar;
    }
    /**
     * Determines if best hand StudPokerHand is a Flush
     * @return the true if StudPokerHand's best hand is a Flush, otherwise false
     */
    public boolean isFlush(){
        return this.getBestFiveCardHand().isFlush();
    }
    /**
     * Determines if best hand StudPokerHand is a TwoPair
     * @return the true if StudPokerHand's best hand is a TwoPair, otherwise false
     */
    public boolean isTwoPair(){
        return this.getBestFiveCardHand().isTwoPair();
    }
    /**
     * Determines if best hand StudPokerHand is a Pair
     * @return the true if StudPokerHand's best hand is a Pair, otherwise false
     */
    public boolean isPair(){
        return this.getBestFiveCardHand().isPair();
    }
    /**
     * Determines if best hand StudPokerHand is a High
     * @return the true if StudPokerHand's best hand is a High, otherwise false
     */
    public boolean isHigh(){
        return this.getBestFiveCardHand().isHigh();
    }
    /**
     * Chooses all combinations of length howMany from the list from
     * @param from list to choose from
     * @param howMany the size of the list of each combination
     * @return the list of different combinations of list of Cards
     */
    private ArrayList<ArrayList<Card>> choose(ArrayList<Card> from, int howMany) {
        ArrayList<ArrayList<Card>> listOfCardsList = new ArrayList<ArrayList<Card>>();
        if (from.size() == howMany) {
            listOfCardsList.add(from);
        }
        else if (howMany == 1) {
            for (Card card : from) {
                ArrayList<Card> cardList = new ArrayList<Card>();
                cardList.add(card);
                listOfCardsList.add(cardList);
            }
        }
        else{
            Card firstCard = from.get(0);
            ArrayList<Card> rest = new ArrayList<Card>(from.subList(1,from.size()));
            ArrayList<ArrayList<Card>> restWithFirst =  choose(rest, howMany-1);
            for (ArrayList<Card> cardList: restWithFirst){
                cardList.add(0, firstCard);
            }
            listOfCardsList.addAll(restWithFirst);
            listOfCardsList.addAll(choose(rest,howMany));
        }
        return listOfCardsList;
    }

    /**
     *  Determines how this hand compares to another hand, returns
     *  positive, negative, or zero depending on the comparison.
     *
     *  @param other The hand to compare this hand to
     *  @return a negative number if this is worth LESS than other, zero
     *  if they are worth the SAME, and a positive number if this is worth
     *  MORE than other
     */
    public int compareTo(StudPokerHand other) {
        return this.getBestFiveCardHand().compareTo(other.getBestFiveCardHand());
    }
    //getBestFiveCardHand is private to the class, which makes other.getBest... legal

    /**
     * Compares if two StudPokerHands are the same
     * @return True if StudPokerHands are Equal, False otherwise
     */
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        } else if (other == null) {
            return false;
        } else if (!(other instanceof StudPokerHand)) {
            return false;
        } else {
            StudPokerHand otherHand = (StudPokerHand) other; //casting other to be a StudPokerHand object
            return otherHand.holeCards.containsAll(this.holeCards); //cards can be in different orders
            //The communityCards does not matter in this case because it is only used to find best PokerHand
            //I'm assuming that StudPokerHand is synonymous to the hole cards.
        }
    }

    public static void main(String[] args){
        Deck D1 = new Deck();
        D1.shuffle();
        CommunityCardSet C1 = new CommunityCardSet();
        for(int i=0; i<COM_CARD_SIZE; i++){
            C1.addCard(D1.dealaCard());
        }
        System.out.println("Community Cards: " + C1);
        StudPokerHand S1 = new StudPokerHand(C1);
        for(int i=0; i<HOLE_CARD_SIZE; i++){
            S1.addCard(D1.dealaCard());
        }
        System.out.println("Stud Cards: " + S1);
        System.out.println("Number of Possible 5-Card Hands: " + S1.getAllFiveCardHands().size());
        System.out.println("All Possible 5-Card Hands: ");
        int number = S1.getAllFiveCardHands().size();
        for (int i = 0; i < number; i++) {
            System.out.println(S1.getAllFiveCardHands().get(i));
        }
        System.out.println("Best 5 Card Hand: " + S1.getBestFiveCardHand());
        System.out.println("Is the community card set still the same? " + C1.getCards().equals(S1.getCommunityCards()));

        System.out.println(S1.choose(S1.combineCommunityCards(),1));
        System.out.println(S1.choose(S1.combineCommunityCards(),7));
        for (ArrayList<Card> CardList: S1.choose(S1.combineCommunityCards(),5)) {
            System.out.println(CardList);
        }
        System.out.println(S1.choose(S1.combineCommunityCards(),5).size());

        CommunityCardSet C2 = new CommunityCardSet();
        for(int i=0; i<COM_CARD_SIZE; i++) {
            C2.addCard(D1.dealaCard());
        }
        System.out.println("Community Cards: " + C2);
        StudPokerHand S2 = new StudPokerHand(C2);
        S2.addCard(new Card(5,"C"));
        S2.addCard(new Card(6,"C"));
        StudPokerHand S3 = new StudPokerHand(C2);
        S3.addCard(new Card(6,"C"));
        S3.addCard(new Card(5,"C"));
        System.out.println("Is S2 and S3 equal: " + S2.equals(S3));

        StudPokerHand S5 = new StudPokerHand(C2);
        S5.dealStudHand(new Card(6,"C"),new Card(5,"C"));
        System.out.println("S5: ");
        System.out.println(S5);
        ArrayList<Card> cards2 = new ArrayList<Card>();
        cards2.add(0, new Card(5,"D"));
        cards2.add(0, new Card(6,"D"));
        cards2.add(0, new Card(7,"D"));
        cards2.add(0, new Card(8,"D"));
        S5.dealStudHand(cards2);
        System.out.println("S5: ");
        System.out.println(S5);


        StudPokerHand S4 = new StudPokerHand(C2);
        S4.addCard(new Card(1,"C"));
        S4.addCard(new Card(2,"C"));
        System.out.println("S4: " + S4);
        for (ArrayList<Card> CardList: S4.choose(S4.combineCommunityCards(),3)) {
            System.out.println(CardList);
        }
        System.out.print("All combinations of S4 in lists of size 4: ");
        System.out.println(S4.choose(S4.combineCommunityCards(),4));
        System.out.print("StudPokerHand 4 choose 3: ");
        System.out.println(S4.choose(S4.combineCommunityCards(),3).size());
        System.out.print("StudPokerHand 4 choose 4 ");
        System.out.println(S4.choose(S4.combineCommunityCards(),4).size());

        System.out.println("Testing Choose with list of four Cards");
        ArrayList<Card> cards = new ArrayList<Card>();
        cards.add(0, new Card(5,"C"));
        cards.add(0, new Card(6,"C"));
        cards.add(0, new Card(7,"C"));
        cards.add(0, new Card(8,"C"));

        System.out.println(cards);
        System.out.println(S4.choose(cards,3));
        System.out.println(S4.choose(cards,3).size());
        System.out.println(S4.choose(cards,2));
        System.out.println(S4.choose(cards,2).size());



    }
}